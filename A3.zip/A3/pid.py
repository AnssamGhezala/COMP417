cumulative_integral = 0.0
dt= 1.0 / 60.0 #60 FPS
prev_position = 0

class PIDController:
    def __init__(self, target_pos):
        self.target_pos = target_pos
        self.Kp = 9500.00
        self.Ki = 5966.39
        self.Kd = 4306.72
        self.bias = 0
        return

    def reset(self):
        return

#TODO: Complete your PID control within this function. At the moment, it holds
#      only the bias. Your final solution must use the error between the 
#      target_pos and the ball position, plus the PID gains. You cannot
#      use the bias in your final answer. 
    def get_fan_rpm(self, vertical_ball_position):
        global cumulative_integral, dt, prev_position
        error = self.target_pos - vertical_ball_position
        cumulative_integral += error * dt
        d = (error - (self.target_pos - prev_position))/dt
        output=(self.Kp*error)+(self.Ki*cumulative_integral)+(self.Kd*d)
        prev_position = vertical_ball_position
        return output
